SELECT COUNT(*) AS numprojects
FROM project
WHERE pstartdate>='2021-01-01' AND pstartdate<='2021-12-31'
;
